package kr.or.ddit.member.service;

public interface IMemberService {

	
	
}
