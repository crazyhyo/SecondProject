package kr.or.ddit.member.dao;

public interface IMemberDao {

}
