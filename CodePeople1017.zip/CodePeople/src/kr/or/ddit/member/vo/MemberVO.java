package kr.or.ddit.member.vo;

import java.util.Date;

public class MemberVO {
	private int mem_no;
	private String mem_nm;
	private String mem_id;
	private String mem_pw;
	private String mem_email;
	private String mem_hp;
	private int mem_zipcode;
	private String mem_addr;
	private int mem_code;
	private int mem_active;
	private int mem_gender;
	private int atch_file_id;
	private int mem_in_com;
	private Date mem_bir;
	private String mem_pass_origl;
	public int getMem_no() {
		return mem_no;
	}
	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}
	public String getMem_nm() {
		return mem_nm;
	}
	public void setMem_nm(String mem_nm) {
		this.mem_nm = mem_nm;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getMem_pw() {
		return mem_pw;
	}
	public void setMem_pw(String mem_pw) {
		this.mem_pw = mem_pw;
	}
	public String getMem_email() {
		return mem_email;
	}
	public void setMem_email(String mem_email) {
		this.mem_email = mem_email;
	}
	public String getMem_hp() {
		return mem_hp;
	}
	public void setMem_hp(String mem_hp) {
		this.mem_hp = mem_hp;
	}
	public int getMem_zipcode() {
		return mem_zipcode;
	}
	public void setMem_zipcode(int mem_zipcode) {
		this.mem_zipcode = mem_zipcode;
	}
	public String getMem_addr() {
		return mem_addr;
	}
	public void setMem_addr(String mem_addr) {
		this.mem_addr = mem_addr;
	}
	public int getMem_code() {
		return mem_code;
	}
	public void setMem_code(int mem_code) {
		this.mem_code = mem_code;
	}
	public int getMem_active() {
		return mem_active;
	}
	public void setMem_active(int mem_active) {
		this.mem_active = mem_active;
	}
	public int getMem_gender() {
		return mem_gender;
	}
	public void setMem_gender(int mem_gender) {
		this.mem_gender = mem_gender;
	}
	public int getAtch_file_id() {
		return atch_file_id;
	}
	public void setAtch_file_id(int atch_file_id) {
		this.atch_file_id = atch_file_id;
	}
	public int getMem_in_com() {
		return mem_in_com;
	}
	public void setMem_in_com(int mem_in_com) {
		this.mem_in_com = mem_in_com;
	}
	public Date getMem_bir() {
		return mem_bir;
	}
	public void setMem_bir(Date mem_bir) {
		this.mem_bir = mem_bir;
	}
	public String getMem_pass_origl() {
		return mem_pass_origl;
	}
	public void setMem_pass_origl(String mem_pass_origl) {
		this.mem_pass_origl = mem_pass_origl;
	}
	
	
}
