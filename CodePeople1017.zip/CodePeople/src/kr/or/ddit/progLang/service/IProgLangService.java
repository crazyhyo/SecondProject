package kr.or.ddit.progLang.service;

import java.util.List;

import kr.or.ddit.progLang.vo.ProgLangVO;

public interface IProgLangService {

	public List<ProgLangVO> selectProgLangList();
}
