package kr.or.ddit.company.vo;

import java.util.Date;

public class CompanyVO {
	private int com_no;
	private int mem_no;
	private int jf_code_no;
	private String com_nm;
	private int com_rev;
	private Date com_date;
	private int com_cnt;
	private String com_hpg;
	private int com_fav;
	private int com_sal;
	private String com_intro;
	private int com_zipcode;
	private String com_addr;
	public int getCom_no() {
		return com_no;
	}
	public void setCom_no(int com_no) {
		this.com_no = com_no;
	}
	public int getMem_no() {
		return mem_no;
	}
	public void setMem_no(int mem_no) {
		this.mem_no = mem_no;
	}
	public int getJf_code_no() {
		return jf_code_no;
	}
	public void setJf_code_no(int jf_code_no) {
		this.jf_code_no = jf_code_no;
	}
	public String getCom_nm() {
		return com_nm;
	}
	public void setCom_nm(String com_nm) {
		this.com_nm = com_nm;
	}
	public int getCom_rev() {
		return com_rev;
	}
	public void setCom_rev(int com_rev) {
		this.com_rev = com_rev;
	}
	public Date getCom_date() {
		return com_date;
	}
	public void setCom_date(Date com_date) {
		this.com_date = com_date;
	}
	public int getCom_cnt() {
		return com_cnt;
	}
	public void setCom_cnt(int com_cnt) {
		this.com_cnt = com_cnt;
	}
	public String getCom_hpg() {
		return com_hpg;
	}
	public void setCom_hpg(String com_hpg) {
		this.com_hpg = com_hpg;
	}
	public int getCom_fav() {
		return com_fav;
	}
	public void setCom_fav(int com_fav) {
		this.com_fav = com_fav;
	}
	public int getCom_sal() {
		return com_sal;
	}
	public void setCom_sal(int com_sal) {
		this.com_sal = com_sal;
	}
	public String getCom_intro() {
		return com_intro;
	}
	public void setCom_intro(String com_intro) {
		this.com_intro = com_intro;
	}
	public int getCom_zipcode() {
		return com_zipcode;
	}
	public void setCom_zipcode(int com_zipcode) {
		this.com_zipcode = com_zipcode;
	}
	public String getCom_addr() {
		return com_addr;
	}
	public void setCom_addr(String com_addr) {
		this.com_addr = com_addr;
	}
	
}
