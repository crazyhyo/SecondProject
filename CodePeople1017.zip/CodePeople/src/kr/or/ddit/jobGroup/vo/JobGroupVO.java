package kr.or.ddit.jobGroup.vo;

public class JobGroupVO {
	private int jg_code_no;
	private String jg_code_nm;
	public int getJg_code_no() {
		return jg_code_no;
	}
	public void setJg_code_no(int jg_code_no) {
		this.jg_code_no = jg_code_no;
	}
	public String getJg_code_nm() {
		return jg_code_nm;
	}
	public void setJg_code_nm(String jg_code_nm) {
		this.jg_code_nm = jg_code_nm;
	}
	
}
