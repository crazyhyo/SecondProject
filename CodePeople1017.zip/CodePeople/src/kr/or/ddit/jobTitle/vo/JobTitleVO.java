package kr.or.ddit.jobTitle.vo;

public class JobTitleVO {
	private int jt_code_no;
	private String jt_code_nm;
	private int jg_code_no;
	public int getJt_code_no() {
		return jt_code_no;
	}
	public void setJt_code_no(int jt_code_no) {
		this.jt_code_no = jt_code_no;
	}
	public String getJt_code_nm() {
		return jt_code_nm;
	}
	public void setJt_code_nm(String jt_code_nm) {
		this.jt_code_nm = jt_code_nm;
	}
	public int getJg_code_no() {
		return jg_code_no;
	}
	public void setJg_code_no(int jg_code_no) {
		this.jg_code_no = jg_code_no;
	}
	
}
