package test;

public class TestClass1 {

 private int n = 0;
  {
	 
	 n = 100;
 }
 
 

 private String x="lily";
}
