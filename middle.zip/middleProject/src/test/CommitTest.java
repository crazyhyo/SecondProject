package test;

public class CommitTest {
	public static void main(String[] args) {
		System.out.println("CommitTest!!");
	}
}
