package test;

public class tetets {

	public static void main(String[] args) {
		System.out.println("hello, wowowowowowowowowowowlddolwodowldowldowasfsafsafsafsafsafsafsafedl");
	}
}
