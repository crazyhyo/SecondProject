package test;

public class HelloSVN {
	public static void main(String[] args) {
		System.out.println("Hello SVN!");
	}
}
