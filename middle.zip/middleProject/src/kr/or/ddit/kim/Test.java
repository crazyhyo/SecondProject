package kr.or.ddit.kim;

public class Test {
	public static void main(String[] args) {
		System.err.println("안녕하세요. 커밋 테스트중입니다...");
		System.err.println(" 안녕하세요~!~!~djasjdlkaskldjaslkdkasjdkl!~!");
		System.out.println("helloe");
	}
}
